package com.example.grade_tool_scaler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
